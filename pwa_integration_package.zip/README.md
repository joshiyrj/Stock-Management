# PWA Integration Guide 🚀
This package contains all the files needed to add Progressive Web App (PWA) capabilities to your Stock Management application.

## 📁 File Placement
Copy the contents of this folder into your root `client/` directory, following this structure:

### ⚙️ Root Directory (`client/`)
- `vite.config.js`: Replaces your existing config. (Adds `vite-plugin-pwa` logic)
- `index.html`: Replaces your existing entry HTML. (Adds PWA `<meta>` tags)
- `package.json`: Contains the `vite-plugin-pwa` dependency. Run `npm install` after copying.

### 🖼️ Public Assets (`client/public/`)
- `icon-*.png` (All sizes): Place these in `client/public/`
- `apple-touch-icon.png`: Place in `client/public/`
- `favicon.svg`: Place in `client/public/`

### 💻 Source Files (`client/src/`)
- `PWAUpdater.jsx`: Place in `client/src/`
- `main.jsx`: Replaces your existing `main.jsx`. (Registers the PWA updater component)

---

## 🛠️ Step-by-Step Instructions
1.  **Backup**: Ensure you have a backup of your existing `client/` folder.
2.  **Copy Files**: Drag and drop the `public/` and `src/` folders into your `client/` directory.
3.  **Overwrite Configs**: Copy `vite.config.js`, `index.html`, and `package.json` to the root `client/` directory.
4.  **Install Dependencies**: Navigate to the `client/` directory and run:
    ```bash
    npm install
    ```
5.  **Build and Test**: PWA functionality is only active in a production build. Run:
    ```bash
    npm run build
    ```
6.  **Verify**: Open the built app in Chrome and look for the "Install" icon in the address bar.

> [!NOTE]
> The service worker is set to `autoUpdate` mode, meaning the app will silently update itself in the background when it detects new changes on your server.
